
news = 'NE'
article = 'AR'

TYPE = [
    (news, 'News'),
    (article, 'Article')
]

BAD_WORDS = [
    'foobar',
    'Foobar',
]